from nose.tools import *
from map import Scene


def test_scene():
    gold = Scene ("GoldScene",
                 """This room has gold in it you can grab. There's a door to the north.""")
    assert_equal(gold.name, "GoldScene")
    assert_equal(gold.paths, {})

def test_scene_paths():
    center = Scene("Center", "Test Scene int the center")
    north = Scene("North", "Test Scene in the north")
    south = Scene ("South", "test Scene in the south")


    center.add_paths({'north': north, 'south': south})
    assert_equal(center.go('north'), north)
    assert_equal(center.go('south'), south)

def test_map():
    start = Scene("Start", "You can go west and down a hole.")
    west = Scene("Trees", "There are trees here. You can go east.")
    down = Scene("Dungeon", "It's dark down here. You can go up.")

    start.add_paths({'west': west, 'down': down})
    west.add_paths({'east': start})
    down.add_paths({'up': start})

    assert_equal(start.go('west'), west)
    assert_equal(start.go('west').go('east'), start)
    assert_equal(start.go('down').go('up'), start)

def test_gothon_game_map():
    assert_equal(START.go('shoot!'), central_death_shoot)
    assert_equal(START.go('dodge!'), central_death_dodge)
    room = START.go('tell a joke')
    assert_equal(scene, laser_weapon_armory)
