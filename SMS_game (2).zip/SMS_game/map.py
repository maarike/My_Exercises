class Scene(object):

    def __init__(self, title, urlname, description, img, m_choice):
        self.title = title
        self.urlname = urlname
        self.description = description
        self.paths = {}
        self.img = img
        self.m_choice = m_choice


    def go(self, direction):
        default_direction = None
        if '*' in self.paths.keys():
            default_direction = self.paths.get('*')
        return  self.paths.get(direction, default_direction)


    def add_paths(self, paths):
        self.paths.update(paths)
# Create the scenes of the game
opening_scene= Scene ("Welcome", "opening_scene",
"""
Ohh hello and welcome to this game!
Are you tired of short days and cold nights?
Do you need a little summer experience to warm up your thoughts?
Well than you're at the right place.
Hope you'll have fun!
""","/static/img/logo.jpg", True)

camping_site = Scene("Camping Site", "camping_site",

"""You just arrived at the Sonne Mond und Sterne Festival.
Luckily You could find a good spot at the camping site right away.
You take a look in the sky and it looks like it's about to rain.
You have to decide whether to build up the pavillion or your tent first.
What's your choice?
""", "/static/img/tent.jpg", True)

camping_site_tent = Scene("Camping Site Tent", "camping_site_tent",
"""
Brave decision!
You try to get the tent out of the package.
You notice that you lost the instruction on how to build up the tent.
Maybe it's somewhere in the car.
But actually you have so much skills that you can build it up by yourself.
Well, at least you think that.
Do you think it's worth it to search for it?
""", "/static/img/decision.jpg",True
)

pavillion_fun = Scene ("Pavillion Fun", "pavillion_fun",
"""
I see, we got a little festival pro here!
You're safe under the pavillion.
You guys are waiting for the rain to be over.
Hmmm what could you in order to spend your time in a useful way?
I mean...you're at a festival, where everybody's aim is to get drunk
and you have to do something in order to forget about the bad weather
am I rigth?
So the only two options you have right now
is playing Flunky Ball or Beer Pong.
What do you choose?
""", "/static/img/tent2.jpg",True)

camping_site_death = Scene ("Death...", "camping_site_death",
"""
Bad decision.
You trusted you not existing skills and failed.
You waste so much time, that the rain completely destroys your tent.
Seems like you have never been on a festival before.
Go home.
""","/static/img/death1.jpg", True)

flunky_ball = Scene ("Flunky Ball", "flunky_ball",
"""
The game is really exciting.
Both teams are doing very well and the very last round will decide who will win this game.
One of your mate made a special condition for the last round and created four different paper snippets
Each one contains another way to hit the bottle in the middle.
You're the lucky person who can pick one.
So do you take number 1, 2, 3, or 4?
Remember your choice is going to decide which team will win this very serious competition.
""","/static/img/flunkyball.jpg", True)

beer_pong = Scene ("Beer Pong", "beer_pong",
"""
Alright alright alright!
That's probably one if the BEST games ever.
Now the question of the question:
Are you team red or team blue?

""","/static/img/images.jpg", True)

beer_pong_death= Scene ("Death...", "beer_pong_death",
"""
The red cups won't give you any luck today...
You loose
"""
,"/static/img/death2.jpg", True)




tennis_ball_win = Scene("Tennis Ball Win", "tennis_ball_win",
"""
You chose snippet nr.1 and got the classic tennis ball.
Since you always use the tennis ball, it's very easy for you to hit the bottle.
Each member of your team finishes their bottle and you win.
Great Job!
So now do you want to prepare your face with some fun neon color?
Or do feel still pretty sober and want to play some beer pong?
"""
,"/static/img/bla.jpg", True)

rugby_ball_death = Scene("Death...", "rugby_ball_death",
"""
Oh no, now you have to throw with a rugby ball.
That' not good, the weird shape confuses you.
Your not hitting the bottle and the other teams wins.
Not a good start for a festival.
Go home.
""","/static/img/death3.jpg", True)

closed_eyes = Scene("Closed Eyes", "closed_eyes",
"""
Well we'll see how this is going to work out.
...
...
...
...
Surprisingly you didn't f**cked this up.
Your team wins!
""","/static/img/wineyes.jpg", False)

kick_ball_death = Scene ("Death...", "kick_ball_death",
"""
Oh dear you have to kick the ball with your foot.
That's too bad, in that case you're a total loser.
You're out
""","/static/img/loser.jpg",True)

neon_colors = Scene ("Neon Colors", "neon_colors",
"""
Time to color your face!
In a few minutes you will make up your way to the festival site.
But before that, you will paint yourself with some really fancy looking neon colors.
Since I don't want to make it that easy for you,
you need to solve one riddle in order to get a fancy make over
You can chose which riddle you want to solve.
1: Name a shower that lights up the sky...
2: Kids love this bouncy sugary treat. It can be very colorful...
3: This monkeys' food makes people slip and fall in cartoons...
4: They say each one is totally unique...
Do you choose riddle 1,2,3 or 4?

""","/static/img/riddle.jpg", True)

riddle_one = Scene ("Riddle One", "riddle_one",
"""
Name a shower that lights up the sky...
...
What's your answer?
"""
,"/static/img/thinking.jpg", False)

riddle_two = Scene ("Riddle Two", "riddle_two",
"""
Kids love this bouncy sugary treat. It can be very colorful...
...
What's your answer?
"""
,"/static/img/thinking.jpg", False)

riddle_three = Scene ("Riddle Three", "riddle_three",
"""
This monkeys' food makes people slip and fall in cartoons...
...
What's your answer?
"""
,"/static/img/thinking.jpg", False)

riddle_four = Scene ("Riddle Four", "riddle_four",
"""
They say each one is totally unique...
...
What's your answer?
"""
,"/static/img/thinking.jpg", False)

neon_colors_death = Scene ("Death...", "neon_colors_death",
"""
Too bad, you couldn't figure out the solution.
You're route"""
,"/static/img/sad.jpg", False)

way_to_festival = Scene ("Way to Festival", "way_to_festival",
"""
Okay, you are well prepared for your favorite acts!
Unfortunately, you lost your friends and now you need to find the way to the festival site on your own.
Damn it's like a fucking labyrinth...well let's do this!
Do you go left or right?

"""
,"/static/img/adventure.jpg", True)

right_direction = Scene ("Right Direction", "right_direction",
"""
You arrive at a big party tent.
You have to go through it in order to go back on the way again.
A guy is coming at you and tells you that you need to guess the right code.
Otherwise he wouldn't let you pass.
The code consists of three numbers between 1 and 3.
There is no number twice.
"""
,"/static/img/math.jpg", False)

riddle_direction = Scene ("Riddle Direction", "riddle_direction",
"""
Alright you're on the right track!
You can already see the stairs so the festival site!
But suddenly a pretty weird and high looking hippie appears and blocks your way.
She says that you need to solve a riddle on order to move on.
Actually you're tired of all those crazy people who wants you to solve riddles and codes...
As if you wouldn't have better things to do!
But it looks like you have no other choice since her creepy looking hippie friends are slolwy coming closer.
Try your best:
Tuesday, Sam and Tom went to a restaurant. The food was delicious, they paid the bill and left. But Sam and Tom didn't pay the bill. So who did?

"""
,"/static/img/think.jpg", False)

security_part = Scene ("Security Part", "security_part",
"""
You're almost there so don't fuck this up!
You only need to pass the security section, which will be no problem.
...At least that's what you think
suddenly you realize that you still have a Feigling Schnaps, the hippie gave you after successfully solving the riddle, in your hand
Since you're not allowed to bring any alcohol to the festival site, you have only two options:
You could drink it or try to hide it in your bra and sneak it in.
So do you want to drink or hide?

""","/static/img/drunk.jpg", True
)

drink_option = Scene ("Drink Option", "drink_option",
"""
Well fuck, this was pure vodka!
Who would think that a damn hippie would trick you!
Unfortunately with all the beer you've already drank, the vodka makes you feel pretty drunk.
And the security guy notices that.
To make sure that you're not too drunk he asks you to 1: stand up on one feet or 2: to go a straight line.
What do you chose, 1 or 2?

""","/static/img/drunk2.jpg", True
)

total_win = Scene ("Total Win", "total_win",
"""
You did it!
Finally you are there and can enjoy all the good music
Have fun!
""","/static/img/sms.jpg", True
)

death_festival = Scene ("Death Festival", "death_festival",
"""
Dumb decision.
You can't hold the balance, fall down and break your leg.
Festival for you is over!
Go home.
""","/static/img/cry.jpg", True
)

opening_scene.add_paths({
    'let the fun begin': camping_site
})

camping_site_tent.add_paths({
    'yes':pavillion_fun,
    'no': camping_site_death
})



camping_site.add_paths({
    'pavillion':pavillion_fun,
    'tent':camping_site_tent

})

pavillion_fun.add_paths({
    'beer pong': beer_pong,
    'flunky ball': flunky_ball

})

flunky_ball.add_paths({
    '1': tennis_ball_win,
    '2':rugby_ball_death,
    '3':neon_colors,
    '4':kick_ball_death,


})

tennis_ball_win.add_paths({
    'beer pong': beer_pong,
    'neon colors': neon_colors,


})

beer_pong.add_paths({
    'red': beer_pong_death,
    'blue': neon_colors

})

neon_colors.add_paths({
    '1': riddle_one,
    '2': riddle_two,
    '3': riddle_three,
    '4': riddle_four
})

riddle_one.add_paths({
    'meteor shower': way_to_festival,
    '*': neon_colors_death
})

riddle_two.add_paths({
    'jello': way_to_festival,
    '*': neon_colors_death
})

riddle_three.add_paths({
    'banana': way_to_festival,
    '*': neon_colors_death
})

riddle_four.add_paths({
    'snowflake': way_to_festival,
    '*': neon_colors_death
})

way_to_festival.add_paths({
    'right': right_direction,
    'left': riddle_direction
})

right_direction.add_paths({
    '321': riddle_direction,
    '*': right_direction


})

riddle_direction.add_paths({
    'tuesday': security_part,
    '*': riddle_direction
})

security_part.add_paths({
    'drink': drink_option,
    'hide': total_win
})

drink_option.add_paths({
    '1': total_win,
    '2': death_festival

})
# Make some useful variables to be used in the web application
SCENES = {
    camping_site.urlname : camping_site,
    camping_site_tent.urlname : camping_site_tent,
    camping_site_death.urlname : camping_site_death,
    pavillion_fun.urlname : pavillion_fun,
    beer_pong.urlname : beer_pong,
    beer_pong_death.urlname: beer_pong_death,
    flunky_ball.urlname : flunky_ball,
    tennis_ball_win.urlname: tennis_ball_win,
    rugby_ball_death.urlname: rugby_ball_death,
    closed_eyes.urlname: closed_eyes,
    kick_ball_death.urlname: kick_ball_death,
    neon_colors.urlname: neon_colors,
    riddle_one.urlname: riddle_one,
    riddle_two.urlname: riddle_two,
    riddle_three.urlname: riddle_three,
    riddle_four.urlname: riddle_four,
    neon_colors_death.urlname: neon_colors_death,
    way_to_festival.urlname: way_to_festival,
    riddle_direction.urlname: riddle_direction,
    security_part.urlname: security_part,
    total_win.urlname: total_win,
    drink_option.urlname: drink_option,
    death_festival.urlname: death_festival,
    opening_scene.urlname: opening_scene


}
START = opening_scene
